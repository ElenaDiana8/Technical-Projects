`timescale 1ns / 1ps

module tb();

logic clk_tb;
logic reset_tb;

Basic_computer dut
    (
        .clk(clk_tb),
        .reset(reset_tb)
    );


initial
begin
    clk_tb = 0;
    forever #5 clk_tb = ~ clk_tb;

end
/*
initial
begin
    reset_tb <= 1;
#10 reset_tb <= 0;

#300 $stop();

end
*/


initial
begin
    reset_tb <= 1;
    @(posedge clk_tb);
    reset_tb <= 0;
#300 $stop();
end

initial
begin
    dut.instr_mem0.mem_instr[0] = 32'b1010_0101_0000_0000__0000_0000_0000_1010; //value load, R5, 10
    dut.instr_mem0.mem_instr[1] = 32'b1010_1000_0000_0000__0000_0000_0001_0000; //value load, R8, 16
    dut.instr_mem0.mem_instr[2] = 32'b0001_0011_0101_1000__0000_0000_0000_0000; //add, R3, R5 R8
    dut.instr_mem0.mem_instr[3] = 32'b1101_0000_0011_0101__0000_0000_0000_0000; //store, R5, R3
    dut.instr_mem0.mem_instr[4] = 32'b1110_0001_0101_0000__0000_0000_0000_0000; //load, R1, R5
    dut.instr_mem0.mem_instr[5] = 32'b1010_0111_0000_0000__0000_0000_0000_1000; //value load, R7, 8
    dut.instr_mem0.mem_instr[6] = 32'b0010_0010_1000_0111__0000_0000_0000_0000; //sub, R2, R8 R7
    dut.instr_mem0.mem_instr[7] = 32'b0011_1001_0101_0111__0000_0000_0000_0000; //mul, R9, R5 R7
    dut.instr_mem0.mem_instr[8] = 32'b0100_1010_0000_0111__0000_0000_0000_0000; //shift right, R10, R7
    dut.instr_mem0.mem_instr[9] = 32'b0110_0100_1010_0101__0000_0000_0000_0000; //and, R4, R10 R5
    
    dut.instr_mem0.mem_instr[10] = 32'b1100_0000_0000_0000__0000_0000_0000_1111; //jmpz, 15
    dut.instr_mem0.mem_instr[11] = 32'b0111_0110_1010_0101__0000_0000_0000_0000; //or, R6, R10 R5
    dut.instr_mem0.mem_instr[12] = 32'b1000_1011_1010_0101__0000_0000_0000_0000; //xor, R11, R10 R5
    dut.instr_mem0.mem_instr[13] = 32'b1011_0000_0000_0000__0000_0000_0000_1110; //jmp, 14
    dut.instr_mem0.mem_instr[14] = 32'b1100_0000_0000_0000__0000_0000_0000_1111; //jmpz, 15
    dut.instr_mem0.mem_instr[15] = 32'b1010_1011_0000_0000__0000_0000_0000_1010; //value load, R11, 10
    dut.instr_mem0.mem_instr[16] = 32'b1010_1100_0000_0000__0000_0000_0000_1010; //value load, R12, 10
    
    dut.instr_mem0.mem_instr[17] = 32'b1111_0000_0000_0000__0000_0000_0000_0000; //halt
end

endmodule
