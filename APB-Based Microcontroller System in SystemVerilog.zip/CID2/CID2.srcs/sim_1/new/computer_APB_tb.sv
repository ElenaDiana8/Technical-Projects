`timescale 1ns / 1ps

module computer_APB_tb();

logic clk_tb;      
logic reset_tb;    
logic pwm_out_tb;  
logic [3:0] btn_in_tb;

computer_APB dut
    (
        .clk(clk_tb),
        .reset(reset_tb),
        .pwm_out(pwm_out_tb),
        .btn_in(btn_in_tb)
    );


initial
begin

    clk_tb = 0;
    forever #1 clk_tb = ~clk_tb;

end


initial
begin

      reset_tb = 1;
      btn_in_tb = 4'b0011;
 #2   reset_tb = 0;  
 #200 $stop(); 

end

initial 
begin
    /*
    //tb pt btn
    dut.instr_mem0.mem_instr[0] = 32'b1010_0000_0000_0000__0000_1000_0000_0000; //VL R0, #2048
    dut.instr_mem0.mem_instr[1] = 32'b1010_0001_0000_0000__0000_1000_0000_0001; //VL R1, #2049
    dut.instr_mem0.mem_instr[2] = 32'b1010_0010_0000_0000__0000_1000_0000_0010; //VL R2, #2050
    dut.instr_mem0.mem_instr[3] = 32'b1010_0011_0000_0000__0000_1000_0000_0011; //VL R3, #2051
    
    dut.instr_mem0.mem_instr[4] = 32'b1110_0100_0000_0000__0000_0000_0000_0000; //LOAD R4, R0 -> R4 = MEM[R0]
    dut.instr_mem0.mem_instr[5] = 32'b1110_0101_0001_0000__0000_0000_0000_0000; //LOAD R5, R1 -> R5 = MEM[R1]
    dut.instr_mem0.mem_instr[6] = 32'b1110_0110_0010_0000__0000_0000_0000_0000; //LOAD R6, R2 -> R6 = MEM[R2]
    dut.instr_mem0.mem_instr[7] = 32'b1110_0111_0011_0000__0000_0000_0000_0000; //LOAD R7, R3 -> R7 = MEM[R3]
    */
    
    /*
    //tb pt memorie
    dut.instr_mem0.mem_instr[0] = 32'b1010_0000_0000_0000__0000_0000_0000_1110; //VL R0, #14
    dut.instr_mem0.mem_instr[1] = 32'b1010_0001_0000_0000__0000_0000_0001_0001; //VL R1, #17
    dut.instr_mem0.mem_instr[2] = 32'b1010_0010_0000_0000__0000_0000_0001_0110; //VL R2, #22
    dut.instr_mem0.mem_instr[3] = 32'b1010_0011_0000_0000__0000_0000_0101_1100; //VL R3, #92
    
    dut.instr_mem0.mem_instr[4] = 32'b1101_0000_0000_0001__0000_0000_0000_0000; //STORE R0, R1 -> MEM[R1] = R0
    dut.instr_mem0.mem_instr[5] = 32'b1101_0000_0010_0011__0000_0000_0000_0000; //STORE R2, R3 -> MEM[R3] = R2
    
    dut.instr_mem0.mem_instr[6] = 32'b1110_0100_0001_0000__0000_0000_0000_0000; //LOAD R4, R1 -> R4 = MEM[R1]
    dut.instr_mem0.mem_instr[7] = 32'b1110_0101_0011_0000__0000_0000_0000_0000; //LOAD R5, R3 -> R5 = MEM[R3]
    
    dut.instr_mem0.mem_instr[8] = 32'b0001_1000_0001_0010__0000_0000_0000_0000; //add, R8, R1 R2
    */
    
   /*
    //tb pt pwm
    dut.instr_mem0.mem_instr[0] = 32'b1010_0000_0000_0000__0000_0100_0000_0001; //VL R0, #1025
    dut.instr_mem0.mem_instr[1] = 32'b1010_0001_0000_0000__0000_0100_0000_0010; //VL R1, #1026
    dut.instr_mem0.mem_instr[2] = 32'b1010_0010_0000_0000__0000_0000_0000_0110; //VL R2, #6
    dut.instr_mem0.mem_instr[3] = 32'b1010_0011_0000_0000__0000_0000_0000_0011; //VL R3, #3
    
    dut.instr_mem0.mem_instr[4] = 32'b1101_0000_0010_0000__0000_0000_0000_0000; //STORE R2, R0 -> MEM[R0] = R2
    dut.instr_mem0.mem_instr[5] = 32'b1101_0000_0011_0001__0000_0000_0000_0000; //STORE R3, R1 -> MEM[R1] = R3
    */

    
    //tb pt mean
    dut.instr_mem0.mem_instr[0]  = 32'b1010_0000_0000_0000__0000_1100_0000_0000; //VL R0, #3072 (prima adresa)
    dut.instr_mem0.mem_instr[1]  = 32'b1010_0001_0000_0000__0000_1100_0000_0001; //VL R1, #3073
    dut.instr_mem0.mem_instr[2]  = 32'b1010_0010_0000_0000__0000_1100_0000_0010; //VL R2, #3074
    dut.instr_mem0.mem_instr[3]  = 32'b1010_0011_0000_0000__0000_1100_0000_0011; //VL R3, #3075
    dut.instr_mem0.mem_instr[4]  = 32'b1010_0100_0000_0000__0000_1100_0000_0100; //VL R4, #3076
    dut.instr_mem0.mem_instr[5]  = 32'b1010_0101_0000_0000__0000_1100_0000_0101; //VL R5, #3077
    
    dut.instr_mem0.mem_instr[6]  = 32'b1010_0110_0000_0000__0000_0000_0000_0001; //VL R6,  #1
    dut.instr_mem0.mem_instr[7]  = 32'b1010_0111_0000_0000__0000_0000_0000_0011; //VL R7,  #3
    dut.instr_mem0.mem_instr[8]  = 32'b1010_1000_0000_0000__0000_0000_0000_0100; //VL R8,  #4
    dut.instr_mem0.mem_instr[9]  = 32'b1010_1001_0000_0000__0000_0000_0000_0101; //VL R9,  #9
    dut.instr_mem0.mem_instr[10] = 32'b1010_1010_0000_0000__0000_0000_0000_1100; //VL R10, #12
    
    dut.instr_mem0.mem_instr[11] = 32'b1101_0000_0110_0000__0000_0000_0000_0000; //STORE R6,  R0 -> MEM[R0] = R6  (=1)
    dut.instr_mem0.mem_instr[12] = 32'b1101_0000_0111_0001__0000_0000_0000_0000; //STORE R7,  R1 -> MEM[R1] = R7  (=3)
    dut.instr_mem0.mem_instr[13] = 32'b1101_0000_1000_0010__0000_0000_0000_0000; //STORE R8,  R2 -> MEM[R2] = R8  (=4)
    dut.instr_mem0.mem_instr[14] = 32'b1101_0000_1001_0011__0000_0000_0000_0000; //STORE R9,  R3 -> MEM[R3] = R9  (=9)
    dut.instr_mem0.mem_instr[15] = 32'b1101_0000_1010_0100__0000_0000_0000_0000; //STORE R10, R4 -> MEM[R4] = R10 (=12)
    
    
    dut.instr_mem0.mem_instr[16] = 32'b1110_1011_0001_0000__0000_0000_0000_0000; //LOAD R11, R1 -> R11 = MEM[R1]
    dut.instr_mem0.mem_instr[17] = 32'b1110_1100_0010_0000__0000_0000_0000_0000; //LOAD R12, R2 -> R12 = MEM[R2]
    dut.instr_mem0.mem_instr[18] = 32'b1110_1101_0011_0000__0000_0000_0000_0000; //LOAD R13, R3 -> R13 = MEM[R3]
    dut.instr_mem0.mem_instr[19] = 32'b1110_1110_0100_0000__0000_0000_0000_0000; //LOAD R14, R4 -> R14 = MEM[R4]
    dut.instr_mem0.mem_instr[20] = 32'b1110_1111_0101_0000__0000_0000_0000_0000; //LOAD R15, R5 -> R15 = MEM[R5]
  
 

    
    

end



endmodule
