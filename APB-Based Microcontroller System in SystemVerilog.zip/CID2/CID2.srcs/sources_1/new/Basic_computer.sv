module Basic_computer
    (
        input logic clk,
        input logic reset
    );
    
logic [31:0] instr_mem_x_processor;
logic [15:0] data_mem_x_processor;
logic [15:0] processor_x_data_mem_addr_read, processor_x_data_mem_addr_write;
logic [15:0] processor_x_data_mem_data_write;
logic [7:0] processor_x_instr_mem;
logic processor_x_data_mem_en;

Processor processor0
    (
        .clk(clk),
        .reset(reset),
        .instr_mem_data_read(instr_mem_x_processor),
        .data_mem_data_read(data_mem_x_processor),
        .data_mem_addr_read(processor_x_data_mem_addr_read),
        .data_mem_addr_write(processor_x_data_mem_addr_write),
        .data_mem_data_write(processor_x_data_mem_data_write),
        .instr_mem_addr_read(processor_x_instr_mem),
        .data_mem_w_en(processor_x_data_mem_en)
    );
    
    
instr_mem instr_mem0
    (
        .addr_read(processor_x_instr_mem),
        .data_read(instr_mem_x_processor)
    );
    
data_mem data_mem0
    (
        .clk,
        .w_en(processor_x_data_mem_en),
        .addr_read(processor_x_data_mem_addr_read),
        .addr_write(processor_x_data_mem_addr_write),
        .data_write(processor_x_data_mem_data_write),
        .data_read(data_mem_x_processor)
    );            
    
endmodule
