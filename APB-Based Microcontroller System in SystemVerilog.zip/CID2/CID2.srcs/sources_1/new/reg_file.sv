module reg_file
    (
        input logic clk,
        input logic [3:0] addr_operand0,
        output logic [15:0] operand0,
        input logic [3:0] addr_operand1,
        output logic [15:0] operand1,
        input logic w_en,
        input logic [3:0] addr_result,
        input logic [15:0] data_write
    );
    
    logic [15:0] mem[0:15];
    
    assign operand0 = mem[addr_operand0];
    assign operand1 = mem[addr_operand1];
    
    always_ff@(posedge clk)
    begin
        if(w_en)
            mem[addr_result] <= data_write;
    
    end
    
endmodule
