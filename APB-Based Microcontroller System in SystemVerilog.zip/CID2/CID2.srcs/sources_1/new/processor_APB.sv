module processor_APB
    (
        input logic clk,
        input logic reset,
        
        //conexiuni memorie instructiuni
        input logic [31:0] instr_mem_data_read,
        output logic [7:0] instr_mem_addr_read,
        
        //conexiuni APB
        output logic pclk,
        output logic preset,
        output logic [9:0] paddr,
        output logic psel,
        output logic penable,
        output logic pwrite,
        output logic [15:0] pwdata,
        input logic [15:0] prdata,
        input logic pready,
        output logic [1:0] perriferal_select
    );
 
 logic ralu_x_control_block, control_block_x_ralu, control_block_x_pc_en, control_block_x_pc_jump;
 logic APB_Master_block_pc; 
 logic data_mem_w_en;
 logic [15:0] data_mem_data_read;
 logic [15:0] data_mem_addr_read;
 logic [15:0] data_mem_addr_write;
 logic [15:0] data_mem_data_write;
 

control_block control_block2
    (
        .opcode(instr_mem_data_read[31:28]),
        .zero_flag(ralu_x_control_block),
        .ralu_w_en(control_block_x_ralu),
        .pc_en(control_block_x_pc_en),
        .do_jump(control_block_x_pc_jump),
        .data_mem_w_en(data_mem_w_en)
    );   
    
RALU ralu1
    (
        .clk(clk),
        .opcode(instr_mem_data_read[31:28]),
        .addr_operand0(instr_mem_data_read[23:20]),
        .addr_operand1(instr_mem_data_read[19:16]),
        .w_en(control_block_x_ralu),
        .addr_result(instr_mem_data_read[27:24]),
        .data_mem_data_read(data_mem_data_read),
        .instr_value(instr_mem_data_read[15:0]),
        .operand0(data_mem_addr_read),
        .operand1(data_mem_addr_write),
        .result(data_mem_data_write),
        .zero_flag(ralu_x_control_block)
    );
    
 PC pc1
    (
        .clk(clk),
        .reset(reset),
        .en(control_block_x_pc_en & ~APB_Master_block_pc),
        .do_jump(control_block_x_pc_jump),
        .jump_value(data_mem_data_write[7:0]),
        .pc(instr_mem_addr_read)
    );             
    
    
APB_Master APB_Master2
    (
       .clk(clk),
       .reset(reset),
        
        // interface to processor
        .data_mem_addr_read(data_mem_addr_read),
        .data_mem_addr_write(data_mem_addr_write),
        .data_mem_data_write(data_mem_data_write),
        .data_mem_data_read(data_mem_data_read),
        .block_pc(APB_Master_block_pc),
        .write_transfer(data_mem_w_en),
        .read_transfer(instr_mem_data_read[31:28] == 14),
        
        // APB
        .pclk(pclk),
        .preset(preset),
        .paddr(paddr),
        .psel(psel),
        .penable(penable),
        .pwrite(pwrite),
        .pwdata(pwdata),
        .prdata(prdata),
        .pready(pready),
        .perriferal_select(perriferal_select)
    );
    
endmodule
