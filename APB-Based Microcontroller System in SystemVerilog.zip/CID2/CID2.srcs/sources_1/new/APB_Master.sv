module APB_Master
    (
        input logic clk,
        input logic reset,
        
        // interface to processor
        input logic [15:0] data_mem_addr_read,
        input logic [15:0] data_mem_addr_write,
        input logic [15:0] data_mem_data_write,
        output logic [15:0] data_mem_data_read,
        output logic block_pc,
        input logic write_transfer,
        input logic read_transfer,
        
        // APB
        output logic pclk,
        output logic preset,
        output logic [9:0] paddr,
        output logic psel,
        output logic penable,
        output logic pwrite,
        output logic [15:0] pwdata,
        input logic [15:0] prdata,
        input logic pready,
        output logic [1:0] perriferal_select
    );
    
    
localparam IDLE = 0;
localparam ACCES = 1;
localparam TRANSFER = 2;

logic [1:0] state, state_next;

always_ff @(posedge clk)
begin

    if(reset)
        state <= IDLE;
    
    else state <= state_next;    

end

always_comb
begin
    // mie nu imi place sa scriu aici. tu daca vrei modifica.
    state_next = state;
    case(state)
        IDLE:
            begin
            if( (write_transfer == 1) || (read_transfer == 1) ) 
                begin
                state_next = ACCES;
                end
            else
                begin
                state_next = IDLE;
                end 
            end
        ACCES:
            begin
            state_next = TRANSFER;
            end
        TRANSFER:
            begin
            if(pready == 1)
                begin
                if( (write_transfer == 1) || (read_transfer == 1) )
                    begin
                    state_next = ACCES;
                    end
                else
                    begin
                    state_next = IDLE;
                    end
                end
            else
                begin
                state_next = TRANSFER;
                end 
            end
        default:
            begin
            state_next = IDLE;
            end
    endcase 
end
  
assign pclk = clk;
assign preset = reset;  
  
always_comb
begin
    data_mem_data_read = 0;
    block_pc = 0;
    paddr = 0;
    psel = 0;
    penable = 0;
    pwrite = 0;
    pwdata = 0;
    perriferal_select = 0;
    
    case(state)
        
        IDLE: 
        begin
            if(write_transfer == 1 || read_transfer == 1) block_pc = 1;
        end
        
        ACCES: 
        begin
            block_pc = 1;
            paddr = (write_transfer) ? data_mem_addr_write: data_mem_addr_read;
            perriferal_select = (write_transfer) ? data_mem_addr_write[11:10]: data_mem_addr_read[11:10];
            psel = 1;
            pwrite = write_transfer;
            pwdata = (write_transfer) ? data_mem_data_write : 0;
        
        end
        
        TRANSFER:
        begin
            data_mem_data_read = (~pwrite & pready) ? prdata: 0;
            block_pc = ~pready;
            paddr = (write_transfer) ? data_mem_addr_write: data_mem_addr_read;
            perriferal_select = (write_transfer) ? data_mem_addr_write[11:10]: data_mem_addr_read[11:10];
            psel = 1;
            penable = 1;
            pwrite = write_transfer;
            pwdata = (write_transfer) ? data_mem_data_write : 0;
        end
    
    endcase

end
  

    
endmodule










