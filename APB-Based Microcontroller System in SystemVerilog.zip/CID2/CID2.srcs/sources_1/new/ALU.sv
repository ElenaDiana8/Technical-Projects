module ALU(
    input logic [3:0] opcode,
    input logic [15:0] operand0,
    input logic [15:0] operand1,
    output logic [15:0] result,
    output logic zero
    );
    
    always_comb begin
        if(result)
            zero = 1'b0;
        else 
            zero = 1'b1; 
        end
    
    always_comb
    begin
        case(opcode)
            4'd0 : result = operand0; // nop
            4'd1 : result = operand0 + operand1; //add
            4'd2 : result = operand0 - operand1; //sub
            4'd3 : result = operand0 * operand1; //multiplication
            4'd4 : result = operand1>>1; //shift 1 right
            4'd5 : result = 15'd0; // not implemented
            4'd6 : result = operand0 & operand1; //and bit by bit
            4'd7 : result = operand0 | operand1; //or bit by bit
            4'd8 : result = operand0 ^ operand1; //xor bit by bit
            4'd9 : result = 15'd0; // not implemented
            4'd10 : result = operand1; //se incarca valoarea din operand1
            4'd11 : result = operand1; //se incarca valoarea din operand1
            4'd12 : result = operand1; //se incarca valoarea din operand1
            4'd13 : result = operand0; //se incarca valoarea din operand0
            4'd14 : result = operand1; //se incarca valoarea din operand1
            4'd15 : result = 15'd0; //se blocheaza alu deci nu conteaza
            default: result  = 15'd0;
        endcase
    end 
    
    
    
        
endmodule
