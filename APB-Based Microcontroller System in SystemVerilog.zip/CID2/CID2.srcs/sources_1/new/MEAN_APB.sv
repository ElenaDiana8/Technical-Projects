module MEAN_APB
    (
        //conexiuni APB
        
        input logic pclk,
        input logic preset,
        input logic [9:0] paddr,
        input logic psel,
        input logic penable,
        input logic pwrite,
        input logic [15:0] pwdata,
        output logic [15:0] prdata,
        output logic pready
    );
    
    
logic [1:0] configure;
logic [15:0] data_a, data_b, data_c, data_d, result;
logic [15:0] a, b, c, d;
logic [17:0] result_inter;
logic ct;



//scriere

always_ff@(posedge pclk)
begin
    pready <= 1;
    if(preset)
        begin
            configure <= 0;
            data_a <= 0;
            data_b <= 0;
            data_c <= 0;
            data_d <= 0;
            result <= 0; 
            a <= 0;
            b <= 0;
            c <= 0;
            d <= 0;
            result_inter <=0; 
            ct <= 0;         
        end
        
    else if(psel & penable & pwrite & pready)
        begin
            case(paddr)
                0: configure <= pwdata[1:0];
                1: begin
                    data_a <= pwdata;
                    a <= pwdata;
                   end 
                2: begin
                    data_b <= pwdata;
                    b <= pwdata;
                   end   
                3: begin
                    data_c <= pwdata;
                    c <= pwdata;
                   end
                4: begin
                    data_d <= pwdata;
                    d <= pwdata;
                   end
                5: result <= 0;
                default:
                    begin
                    // intentionat gol
                    end
            
            endcase
        
        end    

end


always_comb
begin
    if(configure == 1)
    begin
        result_inter = (a + b + c + d) >> 2;
        
        if(paddr == 4)
        begin
  
            if(ct < 1)
            begin
                ct++;
            
            end
        
            else
            begin
                result = result_inter[15:0];
                configure = 2;
                
            end    
        end
    end
end

//citire
always_comb
begin
   
    if(psel & penable & ~pwrite & pready)
        begin
            case(paddr)
                0: prdata = {14'b0, configure};
                1: prdata = data_a;
                2: prdata = data_b;
                3: prdata = data_c;
                4: prdata = data_d;
                5: prdata = result;
                default:
                    begin
                    prdata = 0;
                    end
            
            endcase
        end
        
    else prdata = 0;  

end

    
endmodule
